To compress into zip folder"

```pwsh
Compress-Archive -Path * -DestinationPath deploy.zip -Force
```
